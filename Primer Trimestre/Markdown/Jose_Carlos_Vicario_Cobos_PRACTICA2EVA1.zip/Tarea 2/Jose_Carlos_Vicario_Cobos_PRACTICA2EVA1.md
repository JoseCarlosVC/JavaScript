## Instalación de entornos de desarrollo  
|**VS Code**|**Atom**|**Brackets**|  
| -- | -- | -- |  
| ![VSCode logo](./vscode.png "VSCode logo") | ![Atom logo](./atom.png "Atom logo") | ![Brackets logo](./brackets.png "Brackets logo") |  
| [VSCode](https://code.visualstudio.com/) | [Atom](https://atom.io/) | [Brackets](https://brackets.io/) |  
> sudo snap install --classic code  

<!-- -->  
> wget -q https://packagecloud.io/AtomEditor/atom/gpgkey -O- | sudo apt-key add -  
>sudo add-apt-repository "deb [arch=amd64] https://packagecloud.io/AtomEditor/atom/any/ any main"  
> sudo apt install atom  

<!-- -->
> sudo snap install brackets --classic